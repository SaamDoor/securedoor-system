import { formatJalaliDate } from '@/lib/utils'
import { getWebhookLogsAction } from '../../actions'

export default async function ErrorLogPage() {
  const result = await getWebhookLogsAction()
  const logs = result.ok ? (result.data ?? []).filter((item: Record<string, any>) => item.success === false) : []

  return (
    <div dir="rtl" className="min-h-screen bg-zinc-900 p-6">
      <div className="mx-auto max-w-6xl">
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-zinc-100">لاگ خطاها</h1>
          <p className="mt-1 text-zinc-400">خطاهای webhook_logs (success=false)</p>
        </div>

        {!result.ok && <div className="mb-4 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">{result.error}</div>}

        <div className="overflow-hidden rounded-xl bg-zinc-800">
          <table className="w-full">
            <thead>
              <tr className="border-b border-zinc-700">
                <th className="px-6 py-3 text-right text-xs font-medium text-zinc-400">وب‌هوک</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-zinc-400">پیام</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-zinc-400">کد وضعیت</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-zinc-400">تاریخ</th>
              </tr>
            </thead>
            <tbody>
              {logs.length === 0 ? (
                <tr><td colSpan={4} className="px-6 py-10 text-center text-sm text-zinc-500">لاگ خطای وب‌هوک یافت نشد</td></tr>
              ) : logs.map((log: Record<string, any>) => (
                <tr key={log.id} className="border-b border-zinc-700/50 hover:bg-zinc-700/30 transition-colors">
                  <td className="px-6 py-4 text-sm text-zinc-300">{log.webhook?.name ?? '—'}</td>
                  <td className="px-6 py-4 text-sm text-zinc-300">{log.error ?? log.response_body ?? 'نامشخص'}</td>
                  <td className="px-6 py-4 text-sm text-red-300">{log.status_code ?? '—'}</td>
                  <td className="px-6 py-4 text-sm text-zinc-400">{log.created_at ? formatJalaliDate(log.created_at) : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
